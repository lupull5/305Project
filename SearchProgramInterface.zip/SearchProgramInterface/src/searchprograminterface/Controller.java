/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package searchprograminterface;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Accordion;
import javafx.scene.control.Button;
import javafx.scene.control.TitledPane;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

/**
 * FXML Controller class
 *
 * @author arnol
 */
public class Controller implements Initializable {

    @FXML
    private Color x2;
    @FXML
    private Font x1;
    
    @FXML private Accordion categories;
    @FXML private TitledPane year;
    @FXML private TitledPane gender;
    @FXML private TitledPane prize;
    @FXML private Button male; 
    @FXML private Button female; 

    static Map<String, String> searchQuery = new HashMap<>();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }    

    @FXML
    private void searchButtonClicked(ActionEvent event) {
        System.out.println("Searching...");
    }
    
    @FXML
    private void exitButtonClicked(ActionEvent event) throws IOException {
        Platform.exit();
    }
    
    // Accordion with selectable search queries 
    
    // Year Tab
    
    @FXML
    private Map<String, String> search1900(ActionEvent event) {
        if(!searchQuery.containsValue("1900")){
            searchQuery.put("Year", "1900");
            System.out.println("Will search for decade 1900s");
        }else{
            searchQuery.remove("Year", "1900");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }    

    @FXML
    private Map<String, String> search1910(ActionEvent event) {
        if(!searchQuery.containsValue("1910")){
            searchQuery.put("Year", "1910");
            System.out.println("Will search for decade 1910s");
        }else{
            searchQuery.remove("Year", "1910");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }
    
    @FXML
    private Map<String, String> search1920(ActionEvent event) {
        if(!searchQuery.containsValue("1920")){
            searchQuery.put("Year", "1920");
            System.out.println("Will search for decade 1920s");
        }else{
            searchQuery.remove("Year", "1920");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }   
    
    //Gender Tab
    
    /**
     * When male button is clicked, male gender is added to the query dictionary.
     * If male button is clicked again, male will be removed from search query.
     */
    @FXML
    private Map<String, String> searchMale(ActionEvent event) {
        if(!searchQuery.containsValue("Male")){
            searchQuery.put("Gender", "Male");
            System.out.println("Will search for male");
        }else{
            searchQuery.remove("Gender", "Male");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }

    /**
     * When Female button is clicked, Female gender is added to the query dictionary.
     * If Female button is clicked again, Female will be removed from search query.
     */
    @FXML
    private Map<String, String> searchFemale(ActionEvent event) {
        if(!searchQuery.containsValue("Female")){
            searchQuery.put("Gender", "Female");
            System.out.println("Will search for Female");
        }else{
            searchQuery.remove("Gender", "Female");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }
    
    
    

    
}
