/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package searchprograminterface;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Accordion;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

/**
 * FXML Controller class
 *
 * @author arnol
 */
public class Controller implements Initializable {

    @FXML
    private Color x2;
    @FXML
    private Font x1;
    
    @FXML private Accordion categories;
    @FXML private TitledPane year;
    @FXML private TitledPane gender;
    @FXML private TitledPane prize;
    @FXML private Button male; 
    @FXML private Button female; 
    @FXML private TextArea results;
    @FXML private TextField userIn;

    static Map<String, String> searchQuery = new HashMap<>();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }    

    @FXML
    private void searchButtonClicked(ActionEvent event) {
        System.out.println("Searching...");
    }
    
    @FXML
    private void exitButtonClicked(ActionEvent event) throws IOException {
        Platform.exit();
    }
    
    // Accordion with selectable search queries 
    
    // Year Tab
    
    @FXML
    private Map<String, String> search1900(ActionEvent event) {
        if(!searchQuery.containsValue("1900")){
            searchQuery.put("Year", "1900");
            System.out.println("Will search for decade 1900s");
        }else{
            searchQuery.remove("Year", "1900");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }    

    @FXML
    private Map<String, String> search1910(ActionEvent event) {
        if(!searchQuery.containsValue("1910")){
            searchQuery.put("Year", "1910");
            System.out.println("Will search for decade 1910s");
        }else{
            searchQuery.remove("Year", "1910");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }
    
    @FXML
    private Map<String, String> search1920(ActionEvent event) {
        if(!searchQuery.containsValue("1920")){
            searchQuery.put("Year", "1920");
            System.out.println("Will search for decade 1920s");
        }else{
            searchQuery.remove("Year", "1920");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }  

    @FXML
    private Map<String, String> search1930(ActionEvent event) {
        if(!searchQuery.containsValue("1930")){
            searchQuery.put("Year", "1930");
            System.out.println("Will search for decade 1930s");
        }else{
            searchQuery.remove("Year", "1930");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }   
    
    @FXML
    private Map<String, String> search1940(ActionEvent event) {
        if(!searchQuery.containsValue("1940")){
            searchQuery.put("Year", "1940");
            System.out.println("Will search for decade 1940s");
        }else{
            searchQuery.remove("Year", "1940");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }
    
    @FXML
    private Map<String, String> search1950(ActionEvent event) {
        if(!searchQuery.containsValue("1950")){
            searchQuery.put("Year", "1950");
            System.out.println("Will search for decade 1950s");
        }else{
            searchQuery.remove("Year", "1950");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }
    
    @FXML
    private Map<String, String> search1960(ActionEvent event) {
        if(!searchQuery.containsValue("1960")){
            searchQuery.put("Year", "1960");
            System.out.println("Will search for decade 1960s");
        }else{
            searchQuery.remove("Year", "1960");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }
    
    @FXML
    private Map<String, String> search1970(ActionEvent event) {
        if(!searchQuery.containsValue("1970")){
            searchQuery.put("Year", "1970");
            System.out.println("Will search for decade 1970s");
        }else{
            searchQuery.remove("Year", "1970");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }
    
    @FXML
    private Map<String, String> search1980(ActionEvent event) {
        if(!searchQuery.containsValue("1980")){
            searchQuery.put("Year", "1980");
            System.out.println("Will search for decade 1980s");
        }else{
            searchQuery.remove("Year", "1980");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }
    
    @FXML
    private Map<String, String> search1990(ActionEvent event) {
        if(!searchQuery.containsValue("1990")){
            searchQuery.put("Year", "1990");
            System.out.println("Will search for decade 1990s");
        }else{
            searchQuery.remove("Year", "1990");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }
    
    @FXML
    private Map<String, String> search2000(ActionEvent event) {
        if(!searchQuery.containsValue("2000")){
            searchQuery.put("Year", "2000");
            System.out.println("Will search for decade 2000s");
        }else{
            searchQuery.remove("Year", "2000");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }
    
    //Gender Tab
    
    /**
     * When male button is clicked, male gender is added to the query dictionary.
     * If male button is clicked again, male will be removed from search query.
     */
    @FXML
    private Map<String, String> searchMale(ActionEvent event) {
        if(!searchQuery.containsValue("Male")){
            searchQuery.put("Gender", "Male");
            System.out.println("Will search for male");
        }else{
            searchQuery.remove("Gender", "Male");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }

    /**
     * When Female button is clicked, Female gender is added to the query dictionary.
     * If Female button is clicked again, Female will be removed from search query.
     * @return searchQuery - search query dictionary
     */
    @FXML
    private Map<String, String> searchFemale(ActionEvent event) {
        if(!searchQuery.containsValue("Female")){
            searchQuery.put("Gender", "Female");
            System.out.println("Will search for Female");
        }else{
            searchQuery.remove("Gender", "Female");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }
    
    // Prize Tab
    
    /**
     * When Physics button is pressed, Physics is added to the query dictionary 
     * with the key set as prize. If clicked again, Physics would be removed from 
     * query dictionary. 
     * @return searchQuery - search query dictionary
     */
    @FXML
    private Map<String, String> searchPhysics(ActionEvent event) {
        if(!searchQuery.containsValue("Physics")){
            searchQuery.put("Prize", "Physics");
            System.out.println("Will search for Physics");
        }else{
            searchQuery.remove("Prize", "Physics");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }
    
    /**
     * When Chemistry button is pressed, Chemistry is added to the query dictionary 
     * with the key set as prize. If clicked again, Chemistry would be removed from 
     * query dictionary. 
     * @return searchQuery - search query dictionary
     */
    @FXML
    private Map<String, String> searchChemistry(ActionEvent event) {
        if(!searchQuery.containsValue("Chemistry")){
            searchQuery.put("Prize", "Chemistry");
            System.out.println("Will search for Chemistry");
        }else{
            searchQuery.remove("Prize", "Chemistry");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }
    
    /**
     * When Economics button is pressed, Economics is added to the query dictionary 
     * with the key set as prize. If clicked again, Economics would be removed from 
     * query dictionary. 
     * @return searchQuery - search query dictionary
     */
    @FXML
    private Map<String, String> searchEconomics(ActionEvent event) {
        if(!searchQuery.containsValue("Economics")){
            searchQuery.put("Prize", "Economics");
            System.out.println("Will search for Economics");
        }else{
            searchQuery.remove("Prize", "Economics");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }

    /**
     * When Literature button is pressed, Literature is added to the query dictionary 
     * with the key set as prize. If clicked again, Literature would be removed from 
     * query dictionary. 
     * @return searchQuery - search query dictionary
     */
    @FXML
    private Map<String, String> searchLiterature(ActionEvent event) {
        if(!searchQuery.containsValue("Literature")){
            searchQuery.put("Prize", "Literature");
            System.out.println("Will search for Literature");
        }else{
            searchQuery.remove("Prize", "Literature");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }
    
    /**
     * When Medicine button is pressed, Medicine is added to the query dictionary 
     * with the key set as prize. If clicked again, Medicine would be removed from 
     * query dictionary. 
     * @return searchQuery - search query dictionary
     */
    @FXML
    private Map<String, String> searchMedicine(ActionEvent event) {
        if(!searchQuery.containsValue("Medicine")){
            searchQuery.put("Prize", "Medicine");
            System.out.println("Will search for Medicine");
        }else{
            searchQuery.remove("Prize", "Medicine");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }
    
    /**
     * When Peace button is pressed, Peace is added to the query dictionary 
     * with the key set as prize. If clicked again, Peace would be removed from 
     * query dictionary. 
     * @return searchQuery - search query dictionary
     */
    @FXML
    private Map<String, String> searchPeace(ActionEvent event) {
        if(!searchQuery.containsValue("Peace")){
            searchQuery.put("Prize", "Peace");
            System.out.println("Will search for Peace");
        }else{
            searchQuery.remove("Prize", "Peace");
        }
        System.out.println("Dictionary:" + searchQuery);
        return searchQuery;
    }

    @FXML 
    private Map<String, String> searchText(){
        String userSearch = userIn.getText();
        searchQuery.put("Name", "userSearch");
        
        System.out.println("Looking for user written query");
        return searchQuery;
    
    }
    
    @FXML
    private void searchResults(){
        results.setText("Hello");
    }
}
